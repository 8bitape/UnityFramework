﻿using UniRxEventAggregator.Events;

namespace $rootnamespace$
{
    public class $safeitemname$ : PubSubMonoBehaviour
    {
        private void Start()
        {
            
        }
    }
}
