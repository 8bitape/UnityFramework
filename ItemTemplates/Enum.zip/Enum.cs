﻿namespace $rootnamespace$
{
    public enum $safeitemname$
    {
        
    }
}