﻿namespace $rootnamespace$
{
    public class $safeitemname$
    {
        public object Property { get; private set; }

        public $safeitemname$(object property)
        {
            this.Property = property;
        }
    }
}
